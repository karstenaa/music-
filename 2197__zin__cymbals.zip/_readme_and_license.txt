Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by -zin- ( http://www.freesound.org/people/-zin-/  )
You can find this pack online at: http://www.freesound.org/people/-zin-/packs/2197/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 34827___zin___splash_hit_3.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34827/
    * license: Attribution
  * 34826___zin___splash_hit_2_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34826/
    * license: Attribution
  * 34825___zin___splash_hit_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34825/
    * license: Attribution
  * 34824___zin___splash_hit_1_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34824/
    * license: Attribution
  * 34823___zin___splash_hit_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34823/
    * license: Attribution
  * 34822___zin___crash_3_hit_1_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34822/
    * license: Attribution
  * 34821___zin___crash_3_hit_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34821/
    * license: Attribution
  * 34820___zin___crash_2_hit_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34820/
    * license: Attribution
  * 34819___zin___crash_2_hit_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34819/
    * license: Attribution
  * 34818___zin___crash_1_hit_2_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34818/
    * license: Attribution
  * 34817___zin___crash_1_hit_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34817/
    * license: Attribution
  * 34816___zin___crash_1_hit_1_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34816/
    * license: Attribution
  * 34815___zin___crash_1_hit_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34815/
    * license: Attribution
  * 34814___zin___splash_ting_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34814/
    * license: Attribution
  * 34813___zin___splash_ting_1_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34813/
    * license: Attribution
  * 34812___zin___splash_ting_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34812/
    * license: Attribution
  * 34811___zin___crash_3_ting_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34811/
    * license: Attribution
  * 34810___zin___crash_3_ting.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34810/
    * license: Attribution
  * 34809___zin___crash_2_ting_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34809/
    * license: Attribution
  * 34808___zin___crash_2_ting.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34808/
    * license: Attribution
  * 34807___zin___crash_1_ting_cut.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34807/
    * license: Attribution
  * 34806___zin___crash_1_ting.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34806/
    * license: Attribution
  * 34805___zin___splash_bell_3.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34805/
    * license: Attribution
  * 34804___zin___splash_bell_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34804/
    * license: Attribution
  * 34803___zin___splash_bell_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34803/
    * license: Attribution
  * 34802___zin___crash_3_bell_3.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34802/
    * license: Attribution
  * 34801___zin___crash_3_bell_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34801/
    * license: Attribution
  * 34800___zin___crash_3_bell_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34800/
    * license: Attribution
  * 34799___zin___crash_2_bell_3.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34799/
    * license: Attribution
  * 34798___zin___crash_2_bell_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34798/
    * license: Attribution
  * 34797___zin___crash_2_bell_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34797/
    * license: Attribution
  * 34796___zin___crash_1_bell_2.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34796/
    * license: Attribution
  * 34795___zin___crash_1_bell_1.wav
    * url: http://www.freesound.org/people/-zin-/sounds/34795/
    * license: Attribution

